set i2c_master.sv as top
and run the simulation

for read operation, default register is used.
willl implement i2c memory 
